package com.example.jogodaforca

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.jogodaforca.databinding.ActivityTeamSelectionBinding

class TeamSelectionActivity : AppCompatActivity() {
    private lateinit var binding: ActivityTeamSelectionBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTeamSelectionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.buttonFluminense.setOnClickListener {
            iniciarJogo("FLUMINENSE")
        }

        binding.buttonFlamengo.setOnClickListener {
            iniciarJogo("FLAMENGO")
        }

        binding.buttonBack.setOnClickListener {
            finish() // Volta para o menu
        }
    }

    private fun iniciarJogo(time: String) {
        val intent = Intent(this, MainActivity::class.java)
        intent.putExtra("TIME_ESCOLHIDO", time)
        startActivity(intent)
    }
}
