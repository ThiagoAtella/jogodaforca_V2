package com.example.jogodaforca

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider

enum class ForcaGameStatus(val mensagem: String, val acerto: Boolean?) {
    JOGANDO("Jogo em andamento", null),
    GANHOU("Você ganhou!", true),
    PERDEU("Você perdeu!", false)
}

class ForcaViewModel(private val time: String) : ViewModel() {

    private val palavrasFluminense = listOf("FLUMINENSE", "CANO", "TRICOLOR", "CAMPEÃO", "ETERNO")
    private val palavrasFlamengo = listOf("FLAMENGO", "GABIGOL", "MENGO", "HEXACAMPEÃO", "MARACANÃ")

    private val palavras = if (time == "FLAMENGO") palavrasFlamengo else palavrasFluminense
    private var palavra = ""
    private lateinit var palavraOcultaArray: CharArray
    private var tentativasRestantes = 6
    private val letrasTentadas = mutableSetOf<Char>()

    private val _palavraOculta = MutableLiveData<String>()
    val palavraOculta: LiveData<String> get() = _palavraOculta

    private val _tentativas = MutableLiveData<Int>()
    val tentativas: LiveData<Int> get() = _tentativas

    private val _status = MutableLiveData<ForcaGameStatus>()
    val status: LiveData<ForcaGameStatus> get() = _status

    init {
        iniciarNovoJogo()
    }

    fun iniciarNovoJogo() {
        palavra = palavras.random()
        palavraOcultaArray = CharArray(palavra.length) { '_' }
        tentativasRestantes = 6
        letrasTentadas.clear()
        _status.value = ForcaGameStatus.JOGANDO
        atualizarUI()
    }

    fun processarPalpite(letra: Char) {
        if (!letrasTentadas.add(letra)) {
            return  // Se a letra já foi tentada, ignoramos
        }

        var acertou = false
        for (i in palavra.indices) {
            if (palavra[i] == letra) {
                palavraOcultaArray[i] = letra
                acertou = true
            }
        }

        if (!acertou) tentativasRestantes--

        atualizarUI()
        verificarFimDeJogo()
    }

    private fun atualizarUI() {
        _palavraOculta.value = palavraOcultaArray.joinToString(" ") // Adiciona espaço entre letras
        _tentativas.value = tentativasRestantes
    }

    private fun verificarFimDeJogo() {
        when {
            tentativasRestantes <= 0 -> {
                _status.value = ForcaGameStatus.PERDEU
                // Revela a palavra correta ao perder
                _palavraOculta.value = palavra
            }
            palavraOcultaArray.none { it == '_' } -> _status.value = ForcaGameStatus.GANHOU
            else -> _status.value = ForcaGameStatus.JOGANDO
        }
    }
    }


class ForcaViewModelFactory(private val time: String) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ForcaViewModel::class.java)) {
            return ForcaViewModel(time) as T
        }
        throw IllegalArgumentException("Classe ViewModel desconhecida")
    }
}