package com.example.jogodaforca

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.jogodaforca.databinding.ActivityMenuBinding

class MenuActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMenuBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMenuBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.root.setBackgroundResource(R.drawable.cano)

        // Configura o botão para iniciar o jogo
        binding.buttonStartGame.setOnClickListener {
            // Inicia o MainActivity
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        // Configura o botão para sair do aplicativo
        binding.buttonExit.setOnClickListener {
            finishAffinity() // Fecha todas as atividades e sai do aplicativo
        }
    }
}
