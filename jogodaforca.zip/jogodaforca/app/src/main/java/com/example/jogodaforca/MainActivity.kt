package com.example.jogodaforca

import android.graphics.Color
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.jogodaforca.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: ForcaViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val timeEscolhido = intent.getStringExtra("TIME_ESCOLHIDO") ?: "FLUMINENSE"

        viewModel = ViewModelProvider(this, ForcaViewModelFactory(timeEscolhido)).get(ForcaViewModel::class.java)

        configurarObservadores()
        configurarBotoes()
        iniciarNovoJogo()
    }

    private fun configurarObservadores() {
        viewModel.palavraOculta.observe(this) { palavra ->
            binding.textViewWord.text = palavra
        }

        viewModel.tentativas.observe(this) { tentativas ->
            binding.textViewAttempts.text = "Tentativas restantes: $tentativas"
        }

        viewModel.status.observe(this) { status ->
            binding.textViewStatus.text = status.mensagem
            when (status) {
                ForcaGameStatus.PERDEU -> {
                    // Exibe a palavra correta e muda a cor para vermelho
                    binding.textViewWord.setTextColor(Color.RED)
                }
                ForcaGameStatus.GANHOU -> {
                    // Muda a cor para verde ao ganhar
                    binding.textViewWord.setTextColor(Color.GREEN)
                }
                else -> {
                    // Mantém a cor padrão (preto) durante o jogo
                    binding.textViewWord.setTextColor(Color.BLACK)
                }
            }
        }
    }

    private fun configurarBotoes() {
        binding.buttonGuess.setOnClickListener {
            val letra = binding.inputLetter.text.toString().trim().uppercase()
            if (letra.length == 1 && letra[0].isLetter()) {
                viewModel.processarPalpite(letra[0])
            }
            binding.inputLetter.text.clear()
        }

        binding.buttonRestart.setOnClickListener {
            iniciarNovoJogo()
        }
    }

    private fun iniciarNovoJogo() {
        viewModel.iniciarNovoJogo()
        binding.textViewStatus.text = ""
        binding.textViewWord.setTextColor(Color.BLACK)
    }
}