package com.example.jogodaforca

data class GameStatus(val message: String, val acerto: Boolean? = null)
